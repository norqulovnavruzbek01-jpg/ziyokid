export type SubjectId = 
  | 'matematika' 
  | 'ona-tili' 
  | 'adabiyot' 
  | 'informatika' 
  | 'ingliz-tili' 
  | 'uzb-tarixi' 
  | 'jahon-tarixi' 
  | 'geografiya' 
  | 'fizika';

export interface SubjectInfo {
  id: SubjectId;
  title: string;
  icon: string;
  color: string;
  bgColor: string;
  description: string;
  lessonsCount: number;
  topics: Topic[];
}

export interface Topic {
  id: string;
  title: string;
  summary: string;
  content: string;
  quiz: QuizQuestion[];
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface UserProfile {
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  username: string;
  password: string;
  xp: number;
  streak: number;
  completedLessons: string[];
}
